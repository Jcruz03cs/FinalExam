1.in this problem we have to return the maximum product of the atleast 2 positive integers that make up the sum of the given number. to do this we create an int dp array that is the size of n+1
then we fill the array using a for loop, as we are filling in the array dp[i] should maintain the greatest value. as we are filling in the array at position i in the dp array 
we get the max of the value in the dp array at index i, the max between j and the value in dp[j] and we multiply that by the max of i-j and their value in the position in the array minus eachother
we keep doing this till the array is filled then we return the n index in the dp array because it shlould be the max.
2. we use an integer dp array to store the current max as we fill in the array till n is the max.