1. In this problem we are to find the maximum length chain of pairs. In this problem we use a for loop to look at the values at indexes i and 1 in the pairs 2d array to see if they 
areless than the values at indexes j and 0 in the pairs 2d array, if that is true then we recursively set the dp[j] equal to the max of dp[j] or dp[i]+1.then at the end we get the highest 
value stored in the dp array and return that.
2. we store the maximum chain length ending with pair i into the dp[i] through out the foor loop if it true.
