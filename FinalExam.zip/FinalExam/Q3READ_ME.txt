1.For Question 3 we are being asked to return how many palindromes for the given String. The way we will be doing this recursively by looking at a point which is a palindrome by itself
then the points to the left and the right to see if they are the same and if they are we increment our counter.(witch we return to give the total number of palindromes)
and we keep doing thie recursively by repeating this till it isnt a palindrome, then we go to the next character in the string and repeat recursively.
2.we will be using a variable count which is incremented whenever a new palindrome is found,and the variables l and r which show us the char at the position in the string.
as we solve from the beginning of the string we have the left and right variables which see if they are the same if they are we added a new palendrome
