1. For this problem we need to see if the numbers in the array are an arithmetic sequence. To do this we do a for loop that comapre the result of the subtraction of the 
indexes at i and i-1 is equal to the result of the subtraction of i-1 and i-2.if that is true then our curr variable is increment by 1, and our sum variable is = sum +curr.then we increment i by 1
Our sum is the total number of arithmetic sequences at the end of A[i].
2. In this problem we are storing the total number of arithmetic sequences to the int sum variable for every completeion of the if statment. but sum is equal to the current value of sum and the int curr
variable which is incremented by one for everycompletion of the if statement.