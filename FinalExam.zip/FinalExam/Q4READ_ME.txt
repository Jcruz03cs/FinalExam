1. For this problem we need to see if the numbers in the array are an arithmetic sequence.we create a recursive method that would subtract the first two values of the given array and store that value in 
the curr variable. then it would recursively call itself with a different position in the array and see if the two values when subtracted are equal to the curr variable. it would keep doing this recursively 
and would keep updating the sum and curr variables.
2. In this problem we are storing the total number of arithmetic sequences to the int sum variable for every completeion of the if statment. but sum is equal to the current value of sum and the int curr
variable which is incremented by one for everycompletion of the if statement.